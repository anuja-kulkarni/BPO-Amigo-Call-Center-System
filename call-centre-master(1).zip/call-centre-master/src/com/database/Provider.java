package com.database;

public interface Provider {
    
	public static final String projPath = "C:/Project/";
	public static final String DATABASE_NAME = "call_centre_db";
	public static final String DRIVER_NAME = "com.mysql.jdbc.Driver";
	public static final String HOST_NAME = "jdbc:mysql://localhost:3306/";
	public static final String USER_NAME = "root";
	public static final String PASSWORD = "root";
	
}
